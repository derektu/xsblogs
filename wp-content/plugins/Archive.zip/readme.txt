=== Plugin Name ===
Tags: facebook, post, default, image
Requires at least: 2.7.1
Tested up to: 4.1.0
License: LGPLv3/MIT
License URI: http://www.gnu.org/licenses/lgpl.html|http://opensource.org/licenses/MIT

Provide default image when post to facebook

== Description ==

This plugin is used to define the default image when post a wordpress post to facebook.

== Changelog ==

= 1.0.0 =
* Initial Version

