## Description

This plugin is used to define the default image when post a wordpress post to facebook.
